
/* $(document).ready(function() {
    $('#myModal').on('hidden.bs.modal', function (e) {
        // do something...
        $('#myModal video').attr("src", $("#myModal  video").attr("src"));
      })

}); */

$(function(){
    $('.btn-close').click(function(){      
            $('#v01').attr('src', $('#v01').attr('src'));
});

$('.btn-close').click(function(){      
    $('#v02').attr('src', $('#v02').attr('src'));
});

$('.btn-close').click(function(){      
    $('#v03').attr('src', $('#v03').attr('src'));
});
    });



